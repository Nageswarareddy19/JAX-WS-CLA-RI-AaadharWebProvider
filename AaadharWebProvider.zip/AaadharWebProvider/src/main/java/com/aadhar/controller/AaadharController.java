package com.aadhar.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aadhar.dto.AaadharDTO;
import com.aadhar.service.AadharService;
import com.aadhar.service.AadharServiceImpl;

public class AaadharController extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		AaadharDTO dto = null;
		AadharService service = null;

		String fname = null;
		String lname = null;
		String email = null;
		String gender = null;
		String result = null;
		PrintWriter pw=null;
		RequestDispatcher rd=null;
		resp.setContentType("text/html");
		fname = req.getParameter("fname");
		lname = req.getParameter("lname");
		email = req.getParameter("email");
		gender = req.getParameter("gender");
		dto = new AaadharDTO();
		dto.setFirstName(fname);
		dto.setLastName(lname);
		dto.setEmail(email);
		dto.setGender(gender);

		service = new AadharServiceImpl();
		result = service.insert(dto);
		req.setAttribute("result",result);
		rd=req.getRequestDispatcher("/EnrollForm.jsp");
		rd.forward(req, resp);
		

		
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			doGet(req, resp);
	}

}
