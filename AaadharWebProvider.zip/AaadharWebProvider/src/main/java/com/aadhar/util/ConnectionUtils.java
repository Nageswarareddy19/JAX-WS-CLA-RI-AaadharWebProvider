package com.aadhar.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionUtils {
	 
	public static Connection getConnection() {
		Connection con=null;
		String driverClassName="oracle.jdbc.driver.OracleDriver";
		String url="jdbc:oracle:thin:@localhost:1521:orcl";
		String userName="system";
		String password="manager";
		
		//load jdbc Driver
		
		
		try {
			Class.forName(driverClassName);
			con = DriverManager.getConnection(url, userName, password);
		} 
		catch(ClassNotFoundException cnf) {
			cnf.printStackTrace();
		}
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return con;
	}

}
