package com.aadhar.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.spi.DirStateFactory.Result;

import com.aadhar.bo.AadharBO;
import com.aadhar.util.ConnectionUtils;

public class AaadharEnrollDAOImpl implements AaadharEnrollDAO {

	private static final String INSERT_ENROLL_DETAILS = "INSERT INTO AADHAR_ENROLL VALUES(ANO_SEQ.NEXTVAL,?,?,?,?)";

	private static final String FIND_BY_AADHAR_ID = "SELECT * FROM AADHAR_ENROLL WHERE AADHAR_NO=?";

	public int save(AadharBO bo) {
		PreparedStatement ps = null;

		Connection con = null;
		int count = 0;
		// get connection
		con = ConnectionUtils.getConnection();

		try {
			ps = con.prepareStatement(INSERT_ENROLL_DETAILS);
			ps.setString(1, bo.getFirstName());
			ps.setString(2, bo.getLastName());
			ps.setString(3, bo.getEmail());
			ps.setString(4, bo.getGender());
			count = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public List<AadharBO> findById(Long id) {
		
		System.out.println("FindById method is called");
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<AadharBO> listBo = null;

		// get Connection
		con = ConnectionUtils.getConnection();

		// create preparedSatement

		try {

			ps = con.prepareStatement(FIND_BY_AADHAR_ID);
			// set the query params
			ps.setLong(1, id);

			// execute query
			rs = ps.executeQuery();

			// create arrayList Object
			listBo = new ArrayList<AadharBO>();

			while (rs.next()) {
				AadharBO bo = new AadharBO();
				bo.setAadharId(rs.getLong("AADHAR_NO"));
				bo.setFirstName(rs.getString("FIRST_NAME"));
				bo.setLastName(rs.getString("LAST_NAME"));
				bo.setEmail(rs.getString("EMAIL"));
				bo.setGender(rs.getString("GENDER"));
				listBo.add(bo);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return listBo;
	}

}
