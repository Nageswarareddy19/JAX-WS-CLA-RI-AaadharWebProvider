package com.aadhar.dao;

import java.util.List;

import com.aadhar.bo.AadharBO;

public interface AaadharEnrollDAO {

	public int save(AadharBO bo) ;
	
	public List<AadharBO> findById(Long id);
}
