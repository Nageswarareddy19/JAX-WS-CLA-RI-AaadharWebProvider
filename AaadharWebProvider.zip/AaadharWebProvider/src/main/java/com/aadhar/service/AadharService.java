package com.aadhar.service;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import com.aadhar.dto.AaadharDTO;

@WebService(name="aadhar-service")
public interface AadharService {

	public String insert(AaadharDTO dto);
	
	@WebMethod(operationName="findByAadhar")
	public @WebResult(name="aadhar-details") List<AaadharDTO> findByAadharId(@WebParam Long aadharId);
}
