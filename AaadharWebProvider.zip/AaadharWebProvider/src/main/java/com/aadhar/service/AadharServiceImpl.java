package com.aadhar.service;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebService;

import com.aadhar.bo.AadharBO;
import com.aadhar.dao.AaadharEnrollDAO;
import com.aadhar.dao.AaadharEnrollDAOImpl;
import com.aadhar.dto.AaadharDTO;

@WebService(endpointInterface="com.aadhar.service.AadharService")
public class AadharServiceImpl implements AadharService {
	public String insert(AaadharDTO dto) {
		AaadharEnrollDAO dao = null;
		AadharBO bo = null;
		int count = 0;
		// convert dto to bo
		bo = new AadharBO();
		bo.setFirstName(dto.getFirstName());
		bo.setLastName(dto.getLastName());
		bo.setEmail(dto.getEmail());
		bo.setGender(dto.getGender());
		dao = new AaadharEnrollDAOImpl();
		count = dao.save(bo);
		if (count == 1)
			return "Aadhar Enrollment is successfull";
		else
			return "Aadhar Enrollment is fail";
	}

	@Override

	public List<AaadharDTO> findByAadharId(Long aadharId) {
		AaadharEnrollDAO dao = null;
		List<AadharBO> listBO = null;
		List<AaadharDTO> listDTO = null;

		dao = new AaadharEnrollDAOImpl();
		listDTO = new ArrayList<AaadharDTO>();
		listBO = dao.findById(aadharId);
		
		for(AadharBO bo:listBO) {
			AaadharDTO dto=new AaadharDTO();
			dto.setAadharNo(bo.getAadharId());
			dto.setFirstName(bo.getFirstName());
			dto.setLastName(bo.getLastName());
			dto.setEmail(bo.getEmail());
			dto.setGender(bo.getGender());
			listDTO.add(dto);
		}
		
		
		// converting listBO to listDto

		return listDTO;
	}

}
